import click
import requests
import json
import os
import webbrowser  
from tabulate import tabulate
from pathlib import Path
import subprocess
from ray.dashboard.modules.job.cli import job_cli_group
import ray.dashboard.modules.job.cli as job_cli
from ray.job_submission import JobSubmissionClient
from typing import Optional, Tuple, Union
import copy
from d3x_cli.utils import  get_formatted_name,output_convertion
import ray._private.ray_constants as ray_constants
from ray._private.storage import _load_class
from ray._private.utils import get_or_create_event_loop
from ray.autoscaler._private.cli_logger import add_click_logging_options, cf, cli_logger
from ray.dashboard.modules.dashboard_sdk import parse_runtime_env_args
from ray.job_submission import JobStatus, JobSubmissionClient
from ray.dashboard.modules.job.cli_utils import add_common_job_options
from ray.util.annotations import PublicAPI
from subprocess import list2cmdline
import time
import sys
import pprint
from time import strftime, localtime
import yaml

userdata_dir = "/userdata" if "D3X_NAMESPACE" in os.environ else Path.home()
ini_file = f"{userdata_dir}/.d3x.ini"
DOCKER_SERVER = os.environ.get("DOCKER_SERVER","https://index.docker.io/v1/")
DOCKER_USER = os.environ.get("DOCKER_USER","")
DOCKER_PASSWORD = os.environ.get("DOCKER_PASSWORD","")
class Struct:
    def __init__(self, **entries):
        self.__dict__.update(entries)
CLI_CTX_OBJ = None

def get_raycluster(obj, ns=None):
    params = {}
    if ns != None:
        params={"namespace": ns}
    r = requests.get(f"{obj.url}/api/{obj.api_prefix}/ray/clusters/", params=params, headers=obj.headers, verify=False)
    if r.status_code == 200:
        return r.json()
    else:
        print(r.text)
    return []

def get_user_ray_cluster(obj, name = None, uuid= None, user= None, fail=True):
    if user == None:
        if uuid == None:
            user = obj.username
        else:
            user = "*"
    data = get_raycluster(obj, user)
    rcluster = None
    for rcl in data:
        d = rcl["config"]
        if uuid != None:
            if d["uuid"] == uuid:
                rcluster = rcl
                break 
        else :
            if d["user"] == user and d["name"] == name:
                rcluster = rcl
                break
    if rcluster == None and fail:
        print(f" ray cluster  not found")
        
        raise click.Abort()
    return rcluster

@click.group()
@click.pass_obj
def ray(obj):
    """Group for ray commands."""
    ray_address =  os.environ.get("RAY_ADDRESS",None)
    if ray_address != None:
        del os.environ['RAY_ADDRESS']
    global CLI_CTX_OBJ
    CLI_CTX_OBJ = obj
    cluster = None
    if "--help" not in sys.argv:
        cluster = get_cluster(obj, False)
        obj.obj = cluster
    if cluster != None:
        obj.obj = Struct(**cluster["config"])
    if ("job" in sys.argv or "dashboard" in sys.argv) and "--help" not in sys.argv:
        if cluster == None:
            print("You need to run  d3x ray activate or do export RAY_CLUSTER <CLUSTER NAME>; export RAY_CLUSTER_USER <USER> first")
            raise click.Abort()
        if cluster == None or "status" not in cluster or cluster["status"] != "ready":
            print("the cluster does not exist or not in ready state, please run \" d3x ray list \" for checking status of the cluster")
            raise click.Abort()
        else:
            clustername = cluster["config"]["name"]
            owner = cluster["config"]["user"]
            print(f"Ray Cluster Name: {clustername}")
            print(f"Ray Cluster Owner: {owner}")

@ray.command()
@click.pass_obj
@click.option("-n", "--name", required=True, help="name of the ray cluster")
@click.option("-v", "--version",  default="2.11.0", help="version of the ray cluster (default 2.11.0)")
@click.option("-i", "--image", default="", help="image of ray head/worker node")
@click.option("--cpu", default=2, help="ray worker node CPU (default 2)")
@click.option("--gpu", default=0, help="ray worker node GPU (default 0)")
@click.option("--memory", default=4, help="ray worker node memory in GB (default 4)")
@click.option("--hcpu", default=2, help="ray head node CPU (default 2)")
@click.option("--hgpu", default=0, help="ray head node GPU (default 0)")
@click.option("--hmemory", default=4, help="ray head node memory in GB (default 4)")
@click.option('--htype', required=False, help="ray worker head node instance type")
@click.option('--type', required=False, help="ray worker node instance type")
@click.option("--dockerserver", default=DOCKER_SERVER, help="docker registry url")
@click.option("--dockeruser", default=DOCKER_USER, help="docker registry username")
@click.option("--dockerpsw", default=DOCKER_PASSWORD, help="docker registry password")
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
def create(obj, name, version, image, cpu, gpu, memory, hcpu, hgpu, hmemory, htype, type, dockerserver, dockeruser, dockerpsw,output):
    """Create Dev Ray Cluster"""
    data = {"name": name, "user": obj.username, "version": version, "image": image, 
            "cpu_count": cpu, "memory": memory, "gpu_count": gpu,
            "head_cpu_count": hcpu, "head_memory": hmemory, "head_gpu_count": hgpu}
    if htype != None:
        data["head_instance_type"] = htype
    if type != None:
        data["instance_type"] = type
    if dockeruser != None and  dockerpsw != None:
        data["docker_registry_username"] = dockeruser
        data["docker_registry_password"]=  dockerpsw
        data["docker_registry_server"] = dockerserver
    r = requests.post(f"{obj.url}/api/{obj.api_prefix}/ray/clusters/", json=data, headers=obj.headers, verify=False)
    if output is None:
        print (f"cluster create returned {r.text}")
    else:
        output_convertion(r.text, output)
    if r.status_code != 200:
        raise click.Abort()
    else:
        activate_cluster(obj, name,output)

def get_cluster(obj, printerr = True):
    raycluster_name = os.environ.get("RAY_CLUSTER", None)
    raycluster_user = None
    if raycluster_name != None:
        raycluster_user = os.environ.get("RAY_CLUSTER_USER", None)
    if raycluster_user != None:
        cluster = get_user_ray_cluster(obj,name= raycluster_name, user=raycluster_user, fail=False)
        return cluster
    
    if not obj.config.get(obj.profile, "ray-cluster",fallback=None):
        if printerr:
            print("You need to run  d3x ray activate or do export RAY_CLUSTER <CLUSTER NAME>; export RAY_CLUSTER_USER <USER> first")
        return None
    id = obj.config.get(obj.profile, "ray-cluster")
    cluster = get_user_ray_cluster(obj, uuid=id, fail=False)
    return cluster

@ray.command()
@click.pass_obj
@click.option("-o","--output", required=False, default="json",
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
def get(obj,output):
    """Get a Ray Cluster"""
    resp = get_cluster(obj)
    if resp != None:
        output_convertion(resp, output)


@ray.command()
@click.pass_obj
@click.option("-a", "--all", is_flag=True, help="List all ray clusters")
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
def list(obj, all,output):
    """List Ray Clusters"""
    ns  = "*" if all else None
    rclusters = get_raycluster(obj, ns)

    clusters = [["name", "owner", "version", "state", "created", "Image", "head cpu", "head memory(GB)", "head gpu", "cpu", "memory(GB)", "gpu"]]
    for cluster in  rclusters:
        c = Struct(**cluster["config"])
        name = f"{c.name}*" if obj.obj and c.uuid ==  obj.obj.uuid else c.name
        clusters.append([name,c.user, c.version,cluster["status"],c.created_at, c.image, c.head_cpu_count,c.head_memory,c.head_gpu_count, c.cpu_count,c.memory,c.gpu_count])
    if output is None:
        print(tabulate(clusters, headers="firstrow", tablefmt="presto"))
    else:
        output_convertion(clusters, output)
    
@ray.command()
@click.pass_obj
@click.option("-a", "--all", is_flag=True, help="List all ray cluster addresses")
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
def address(obj, all,output):
    """List Ray Clusters Address"""
    ns  = "*" if all else None
    rclusters = get_raycluster(obj, ns)
    clusters = [[ "name", "version", "state","ClusterIP", "cluster ray address", "dashboard"]]
    for cluster in  rclusters:
        c = Struct(**cluster["config"])
        uuid= c.uuid
        name = f"{c.name}*" if obj.obj and uuid ==  obj.obj.uuid else c.name
        clusters.append([name,c.version,cluster["status"],cluster["clusterip"], f"ray://{c.name}-head-svc.{c.user}:10001", f"{obj.url}/{uuid}/dashboard/"])
    if output is None:
        print(tabulate(clusters, headers="firstrow", tablefmt="presto"))
    else:
        output_convertion(clusters, output)
@ray.command()
@click.pass_obj
@click.argument("name")
@click.option("-u", "--user", required=False, default=None, help="name of the ray cluster owner")
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)


def delete(obj, name, user, output):
    """Delete Dev Ray Cluster"""
    params = {}
    if user != None:
        params={"namespace": user}
    r = requests.delete(f"{obj.url}/api/{obj.api_prefix}/ray/clusters/{name}", params=params, headers=obj.headers, verify=False)
    if output is None:
        print (r.text)
    else:
        output_convertion(r.text, output)


@ray.command()
@click.pass_obj
def dashboard(obj):
    """Open Ray dashboard"""
    uuid = obj.obj.uuid
    webbrowser.open(f"{obj.url}/{uuid}/dashboard/", new=0, autoraise=True)

def activate_cluster(obj, cluster, output, user = None):

    c  = get_user_ray_cluster(obj, name=cluster, user=user)
    config = obj.config
    config.set(obj.profile, "ray-cluster", c["config"]["uuid"])
    config.set(obj.profile, "ray-cluster-name", cluster)
    os.environ['RAY_ADDRESS'] = f"ray://{cluster}-head-svc:10001"
    if output is None:
        print (f"please run  \"export RAY_ADDRESS=ray://{cluster}-head-svc:10001\" before running ray program")
        with open(ini_file, "w") as f:
            config.write(f)
        print(f"Activated cluster {cluster}")
        if c["status"] != "ready":
            print("Please check \" d3x ray list \" for getting status of the cluster before submitting the job")

    else:
        ray_address=f"please run  \"export RAY_ADDRESS=ray://{cluster}-head-svc:10001\" before running ray program"
        with open(ini_file, "w") as f:
            config.write(f)
        activated=f"Activated cluster {cluster}"
        if c["status"] != "ready":
            submittingjob="Please check \" d3x ray list \" for getting status of the cluster before submitting the job"
        activatingrayaddreess=ray_address,activated,submittingjob
        output_convertion(activatingrayaddreess, output)
   
@ray.command()
@click.pass_obj
@click.argument("cluster")
@click.option("-u", "--user", required=False, default=None, help="name of the ray cluster owner")
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
def activate(obj, cluster,output, user):
    """Set cluster"""
    activate_cluster(obj, cluster, output, user)


job_command = copy.deepcopy(job_cli_group)
job_command.hidden = False

@job_command.command()
@click.option(
    "--address",
    type=str,
    default=None,
    required=False,
    help=(
        "Address of the Ray cluster to connect to. Can also be specified "
        "using the RAY_ADDRESS environment variable."
    ),
)
@add_common_job_options
@add_click_logging_options
@PublicAPI(stability="stable")
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json",
        ]
    ),
    help="supported only json,yaml",
)

def list(output,address: Optional[str], verify: Union[bool, str], headers: Optional[str] = None):
    """Lists all running jobs and their information.

    Example:
        `ray job list`
    """
    client = job_cli._get_sdk_client(address, verify=verify)
    # Set no_format to True because the logs may have unescaped "{" and "}"
    # and the CLILogger calls str.format().
    # cli_logger.print(pprint.pformat(client.list_jobs()), no_format=True)

    jobs = [["ID", "Name", "Start Time", "End Time", "Status"]]
    for job in client.list_jobs():
        jobs.append([job.job_id, job.submission_id, strftime('%Y-%m-%d %H:%M:%S', localtime(job.start_time/1000)), time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(job.end_time/1000)) if job.end_time != None else "", job.status])
    if output is None:
        print(tabulate(jobs, headers="firstrow", tablefmt="presto"))
    else:
        output_convertion(jobs, output)

@job_command.command()
@click.pass_obj
@click.option(
    "--address",
    type=str,
    default=None,
    required=False,
    help=(
        "Address of the Ray cluster to connect to. Can also be specified "
        "using the RAY_ADDRESS environment variable."
    ),
)
@click.option(
    "--job-id",
    type=str,
    default=None,
    required=False,
    help=("DEPRECATED: Use `--submission-id` instead."),
)
@click.option(
    "--submission-id",
    type=str,
    default=None,
    required=False,
    help=(
        "Submission ID to specify for the job. "
        "If not provided, one will be generated."
    ),
)
@click.option(
    "--runtime-env",
    type=str,
    default=None,
    required=False,
    help="Path to a local YAML file containing a runtime_env definition.",
)
@click.option(
    "--runtime-env-json",
    type=str,
    default=None,
    required=False,
    help="JSON-serialized runtime_env dictionary.",
)
@click.option(
    "--working-dir",
    type=str,
    default=None,
    required=False,
    help=(
        "Directory containing files that your job will run in. Can be a "
        "local directory or a remote URI to a .zip file (S3, GS, HTTP). "
        "If specified, this overrides the option in `--runtime-env`."
    ),
)
@click.option(
    "--metadata-json",
    type=str,
    default=None,
    required=False,
    help="JSON-serialized dictionary of metadata to attach to the job.",
)
@click.option(
    "--entrypoint-num-cpus",
    required=False,
    type=float,
    help="the quantity of CPU cores to reserve for the entrypoint command, "
    "separately from any tasks or actors that are launched by it",
)
@click.option(
    "--entrypoint-num-gpus",
    required=False,
    type=float,
    help="the quantity of GPUs to reserve for the entrypoint command, "
    "separately from any tasks or actors that are launched by it",
)
@click.option(
    "--entrypoint-resources",
    required=False,
    type=str,
    help="a JSON-serialized dictionary mapping resource name to resource quantity "
    "describing resources to reserve for the entrypoint command, "
    "separately from any tasks or actors that are launched by it",
)
@click.option(
    "--no-wait",
    is_flag=True,
    type=bool,
    default=False,
    help="If set, will not stream logs and wait for the job to exit.",
)
@add_common_job_options
@add_click_logging_options
@click.argument("entrypoint", nargs=-1, required=True, type=click.UNPROCESSED)
@PublicAPI
def submit(
    obj,
    address: Optional[str],
    job_id: Optional[str],
    submission_id: Optional[str],
    runtime_env: Optional[str],
    runtime_env_json: Optional[str],
    metadata_json: Optional[str],
    working_dir: Optional[str],
    entrypoint: Tuple[str],
    entrypoint_num_cpus: Optional[Union[int, float]],
    entrypoint_num_gpus: Optional[Union[int, float]],
    entrypoint_resources: Optional[str],
    no_wait: bool,
    verify: Union[bool, str],
    headers: Optional[str],
):
    """Submits a job to be run on the cluster.

    Example:
        `ray job submit -- python my_script.py --arg=val`
    """
    
    if job_id:
        cli_logger.warning(
            "--job-id option is deprecated. Please use --submission-id instead."
        )
    if entrypoint_resources is not None:
        entrypoint_resources = parse_resources_json(
            entrypoint_resources, cli_logger, cf, command_arg="entrypoint-resources"
        )
    if metadata_json is not None:
        metadata_json = parse_metadata_json(
            metadata_json, cli_logger, cf, command_arg="metadata-json"
        )
    
    submission_id = submission_id or job_id

    if ray_constants.RAY_JOB_SUBMIT_HOOK in os.environ:
        # Submit all args as **kwargs per the JOB_SUBMIT_HOOK contract.
        _load_class(os.environ[ray_constants.RAY_JOB_SUBMIT_HOOK])(
            address=address,
            job_id=submission_id,
            submission_id=submission_id,
            runtime_env=runtime_env,
            runtime_env_json=runtime_env_json,
            metadata_json=metadata_json,
            working_dir=working_dir,
            entrypoint=entrypoint,
            entrypoint_num_cpus=entrypoint_num_cpus,
            entrypoint_num_gpus=entrypoint_num_gpus,
            entrypoint_resources=entrypoint_resources,
            no_wait=no_wait,
        )

    client = job_cli._get_sdk_client(address, verify=verify)

    final_runtime_env = parse_runtime_env_args(
        runtime_env=runtime_env,
        runtime_env_json=runtime_env_json,
        working_dir=working_dir,
    )
    job_id = client.submit_job(
        entrypoint=list2cmdline(entrypoint),
        submission_id=submission_id,
        runtime_env=final_runtime_env,
        metadata=metadata_json,
        entrypoint_num_cpus=entrypoint_num_cpus,
        entrypoint_num_gpus=entrypoint_num_gpus,
        entrypoint_resources=entrypoint_resources,
    )
    
    for _ in range(50): 
        job_details = client.get_job_info(job_id)
        if job_details.job_id != None:
            job_id = job_details.job_id
            break
        time.sleep(3)
        
    address = client.get_address()
    username = obj.username
    cluster_name = obj.obj.name
    cluster_uuid = obj.obj.uuid
    raydashboard_url = f"{cluster_uuid}/dashboard/#/jobs/{job_id}"
    filter_string=f"tags.job_id = '{job_id}' and user_id = '{username}' and tag.\"ray cluster\" = '{cluster_name}'"

    data = {
        "job_id": job_id,
        "user_id": username,
        "submission_id": job_details.submission_id,
        "entrypoint": job_details.entrypoint,
        "start_time": str(job_details.start_time),
        "end_time": str(job_details.end_time), 
        "runtime_env": str(job_details.runtime_env),
        "raypage_url": raydashboard_url,
        "cluster_name": cluster_name,
        "filter_string": filter_string
    }
    
    print(f"Job details URL: {obj.url}/jobs")
    print(f"Ray Job URL: {obj.url}/{raydashboard_url}")
    print("Job details:")
    print(json.dumps(data, indent=4, separators=(',', ': ')))

    r = requests.post(f"{obj.url}/api/{obj.api_prefix}/ray/jobs/", json=data, headers=obj.headers, verify=False)
    print(r.text)
        
    print("response: ", r)

    job_cli._log_big_success_msg(f"Job '{job_id}' submitted successfully")

    with cli_logger.group("Next steps"):
        cli_logger.print("Query the logs of the job:")
        with cli_logger.indented():
            cli_logger.print(cf.bold(f"ray job logs {job_id}"))

        cli_logger.print("Query the status of the job:")
        with cli_logger.indented():
            cli_logger.print(cf.bold(f"ray job status {job_id}"))

        cli_logger.print("Request the job to be stopped:")
        with cli_logger.indented():
            cli_logger.print(cf.bold(f"ray job stop {job_id}"))

    cli_logger.newline()
    sdk_version = client.get_version()
    # sdk version 0 does not have log streaming
    if not no_wait:
        if int(sdk_version) > 0:
            cli_logger.print(
                "Tailing logs until the job exits " "(disable with --no-wait):"
            )
            get_or_create_event_loop().run_until_complete(job_cli._tail_logs(client, job_id))
        else:
            cli_logger.warning(
                "Tailing logs is not enabled for job sdk client version "
                f"{sdk_version}. Please upgrade Ray to the latest version "
                "for this feature."
            )

    
@job_command.command()
@click.pass_obj
@click.argument("job_id", required=False)
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json",
        ]
    ),
    help="supported only json,yaml",
)
def show(obj, output, job_id: str):
    """Queries for show details of job.

    Example:
        `ray job show <job id>`
        `ray job show all`  -- to list all the jobs
    NOTE: Use 'ray job list' to fetch job ids
    """
    params={"namespace": "*"}
    r = requests.get(f"{obj.url}/api/{obj.api_prefix}/ray/jobs/", params=params, headers=obj.headers, verify=False)

    if r.status_code == 200:
        resp = r.json()
        if job_id == None or job_id == "all":
            if output is None:
                print(json.dumps(resp, indent=4))
            else:
                output_convertion(resp[0], output)
        else:
            for rayjob in resp:
                if rayjob["cluster_name"] == obj.obj.name and rayjob["user_id"] == obj.obj.user and rayjob["job_id"] == job_id:
                    if output is None:
                        print(json.dumps(rayjob, indent=4))
                    else:
                        output_convertion(rayjob, output)
    else:
        print (r.text)
    
ray.add_command(job_command, name="job")

def get_sdk_client(
    address: Optional[str],
    headers: Optional[str] = None,
    create_cluster_if_needed: bool = False,
    verify: Union[bool, str] = True,
) -> JobSubmissionClient:
    obj = CLI_CTX_OBJ
    if obj.obj == None:
        print("You need to run  d3x ray activate first")
        raise click.Abort()
    if address != None:
        print(f"--address is not supported, ignoring ray address {address}")
    uuid = obj.obj.uuid
    if obj.auth_type == "apikey":
        uuid = f"{uuid}-api"
    address = f"{obj.url}/{uuid}/dashboard/"

    client = JobSubmissionClient(address, create_cluster_if_needed=False, headers=obj.headers, verify=False)
    return client

job_cli._get_sdk_client = get_sdk_client

