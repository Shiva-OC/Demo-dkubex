import click
import sys
from websockets.sync.client import connect
import websockets
import json
import os
import requests
import asyncio
import signal
import ssl
from websockets.exceptions import ConnectionClosedError

ssl_context = ssl.SSLContext()
ssl_context.verify_mode = ssl.CERT_NONE

class ContextObj(object):
    def __init__(self):
        self.url = "http://localhost:8000"
        self.auth_type = "cookie"
        self.headers = {"authorization": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoicnNpbmdoIn0.E5Ae9aZK6WAC36r4X2BD6QJhk_1jvC829anGaZ14vjU0"} 

@click.group()
@click.pass_context
def main(ctx):
    ctx.obj = ContextObj()

def _fm(obj, script, args, api_key, name):
    data = {"pwd": os.getcwd(), "script":script, "args": args, "api_key": api_key, "name": name}
    if "--help" in args:
        r = requests.post(obj.url + "/help", json=data, headers=obj.headers, verify=False, allow_redirects=False)
    else:
        r = requests.post(obj.url + "/run", json=data, headers=obj.headers, verify=False, allow_redirects=False)
    if r.status_code == 200:
        print(r.json())
        return r.json()
    return None

def _logs(obj, job_name):
    url = obj.url.replace("http","ws")
    with connect(f"{url}/logs/{job_name}", additional_headers=obj.headers, open_timeout=420) as websocket:
        try:
            for msg in websocket:
                print(msg, end="", flush=True)
        except ConnectionClosedError:
            print("Timed out waiting. "
              "Please tail the logs using the following command: \n"
              f"kubectl logs -l job-name={job_name} --follow")
        except:
            websocket.close()
            raise

def connect_websocket(url, ssl_context, additional_headers, open_timeout):
    if url.startswith('wss'):
        return connect(url, ssl_context=ssl_context, additional_headers=additional_headers, open_timeout=open_timeout)
    else:
        return connect(url, additional_headers=additional_headers, open_timeout=open_timeout)

@click.group()
@click.pass_obj
def fm(obj):
    """Group for fm commands."""
    if obj.auth_type == "cookie":
        obj.url += "/api/fm"
    else:
        obj.url += "/api/fm-api"

# @fm.command(context_settings=dict(ignore_unknown_options=True, help_option_names=[]))
# @click.pass_obj
# @click.argument('docs_args', nargs=-1, type=click.UNPROCESSED)
# @click.option("-k","--api_key", default="", envvar="OPENAI_API_KEY")
# @click.option("-n","--name", help="job name")
# def docs(obj, api_key, docs_args, name):
#     """run document processing job"""
#     resp = _fm(obj, "dkubex-fm/tools/fmdocs.py", docs_args, api_key, name)

#     if resp and type(resp) == dict and resp["status"] == "OK":
#         _logs(obj, resp["job"])



async def interactive_query(obj, api_key, query_args, name):
    data = {"pwd": os.getcwd(), "script":"dkubex-fm/tools/fmquery.py", "args": query_args, "api_key": api_key, "name": name}
    url = obj.url.replace("http","ws")
    async with websockets.connect(f"{url}/query", extra_headers=obj.headers, open_timeout=420) as websocket:
        await websocket.send(json.dumps(data))

        state = type('', (), {})()
        state.should_read = False

        async def msg_sender():
            while websocket.open:
                if state.should_read:
                    msg = input("") + "\n"
                    await websocket.send(msg.encode())
                    state.should_read = False
                else:
                    await asyncio.sleep(1)

        async def msg_receiver():
            output = ""
            async for msg in websocket:
                print(msg, end="", flush=True)
                output += msg
                if "Question>: " in output:
                    output = ""
                    state.should_read = True

        try:
            await asyncio.gather(msg_sender(), msg_receiver())
        except:
            pass


# @fm.command(context_settings=dict(ignore_unknown_options=True, help_option_names=[]))
# @click.pass_obj
# @click.option("-i", "--interactive", is_flag=True, help="run fmquery in interactive mode")
# @click.argument('query_args', nargs=-1, type=click.UNPROCESSED)
# @click.option("-k", "--api_key", envvar="OPENAI_API_KEY", default="")
# @click.option("-n","--name", help="job name")
# def query(obj, interactive, api_key, query_args, name):
#     """run fm query job"""
#     if interactive and "--help" not in query_args :
#         return asyncio.run (interactive_query(obj, api_key, query_args, name))

#     resp = _fm(obj, "dkubex-fm/tools/fmquery.py", query_args, api_key, name)

#     if resp and type(resp) == dict and resp["status"] == "OK":
#         _logs(obj, resp["job"])

@fm.command(context_settings=dict(ignore_unknown_options=True, help_option_names=[]))
@click.pass_obj
@click.argument('tune_args', nargs=-1, type=click.UNPROCESSED)
@click.option("-k","--api_key", default="", envvar="OPENAI_API_KEY")
def tune(obj, api_key, tune_args):
    """run document processing job"""
    resp = _fm(obj, "dkubex-fm/tools/fmmodel.py", tune_args, api_key, None)
    if resp and type(resp) == dict and resp["status"] == "OK":
        _logs(obj, resp["job"])

@fm.command(context_settings=dict(ignore_unknown_options=True, help_option_names=[]))
@click.pass_obj
@click.argument('trainchunks_args', nargs=-1, type=click.UNPROCESSED)
@click.option("-k","--api_key", default="", envvar="OPENAI_API_KEY")
@click.option("-n","--name", help="job name")
def trainchunks(obj, api_key, trainchunks_args, name):
    """create ray training chunks"""
    resp = _fm(obj, "dkubex-fm/tools/create_train_test_chunks.py", trainchunks_args, api_key, name)
    if resp and type(resp) == dict and resp["status"] == "OK":
        _logs(obj, resp["job"])

@fm.command()
@click.pass_obj
@click.argument('job_name')
def logs(obj, job_name):
    """show logs of given job"""
    _logs(obj, job_name)

@fm.command()
@click.pass_obj
def jobs(obj):
    """list fm jobs"""
    r = requests.get(obj.url + "/jobs",  headers=obj.headers, verify=False, allow_redirects=False)
    print(r.json())

@fm.command()
@click.pass_obj
@click.argument('job_name')
def get(obj, job_name):
    """get job details"""
    r = requests.get(obj.url + f"/jobs/{job_name}",  headers=obj.headers, verify=False, allow_redirects=False)
    print(r.json())

@fm.command()
@click.pass_obj
@click.argument('job_name')
def delete(obj, job_name):
    """delete job"""
    r = requests.delete(obj.url + f"/jobs/{job_name}",  headers=obj.headers, verify=False, allow_redirects=False)
    print(r.json())

main.add_command(fm)
if __name__ == "__main__":
    sys.exit(main())  # pragma: no cover
