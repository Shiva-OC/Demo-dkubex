import click
import requests
import json
from d3x_cli.utils import  get_formatted_name,output_convertion
from d3x_cli.workspace_helper import *
@click.group()
@click.pass_obj
def optuna(obj):
    """Group for optuna commands."""
    global CLI_CTX_OBJ
    CLI_CTX_OBJ = obj

@optuna.command()
@click.pass_obj
@click.argument("db")
@click.option("-o","--output", required=False, default="json",
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
def set_db(obj, db, output):
    """setting db for optuna app inside workspace"""
    w = get_user_workspace(obj, exit=False)
    wid = w.id if w != None else -1
    resp = requests.post(
        f"{obj.url}/api/{obj.api_prefix}/workspaces/{wid}/optuna/db",
        data= json.dumps({"db" : db}),
        headers=obj.headers,
        verify=False,
    )
    if resp.status_code != 200:
        click.echo(resp.text)
        raise click.Abort()
    if output is None:
        click.echo(resp.json()["status"])
    else:
        click.echo(output_convertion(resp.json()["status"], output))

    click.echo(f"updated db for optuna app  to {db}, please restart the optuna app from ui")

@optuna.command()
@click.pass_obj
@click.option("-o","--output", required=False, default="json",
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
def get_db(obj, output):
    """getting db path for optuna"""
    w = get_user_workspace(obj, exit=False)
    wid = w.id if w != None else -1
    resp = requests.get(
        f"{obj.url}/api/{obj.api_prefix}/workspaces/{wid}/optuna/db",
        verify=False,
        headers=obj.headers,
    )
    if resp.status_code != 200:
        click.echo(resp.text)
        raise click.Abort()
    if output is None:
        click.echo(resp.json())
    else:
        click.echo(output_convertion(resp.json(), output))