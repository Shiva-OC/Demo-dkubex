import click
import requests
import json
from tabulate import tabulate
import joblib
import os
import os.path as path
import importlib.util
from d3x_cli.utils import  get_formatted_name,output_convertion

import sys
import os.path as path

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"
mlfc = None


@click.group()
@click.pass_context
def models(ctx):
    """List & Manage mlflow models registry"""
    import mlflow
    import logging

    logging.getLogger("mlflow").setLevel(logging.ERROR)

    global mlfc
    mlfc = mlflow.MlflowClient()


@models.command("import")
@click.argument("name")
@click.argument(
    "model_type",
    type=click.Choice(["pytorch", "tensorflow", "sklearn", "xgboost", "custom_model"]),
)
@click.argument("saved_model_path")
@click.option("--class_path", help="pytorch class file path")
@click.option("--class_instance", help="class instance")
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)

def impt(name, model_type, saved_model_path, class_path, class_instance,output):
    """Import saved model to mlflow"""
    import mlflow.tensorflow
    import mlflow.sklearn
    import mlflow.pytorch
    import mlflow.xgboost
    import mlflow.pyfunc

    class TrainedModel(mlflow.pyfunc.PythonModel):
        def __init__(self, model):
            self.model = model

        def predict(self, context, model_input):
            return {}

    try:
        abs_path = lambda x: os.path.abspath(x)
        saved_model_path = abs_path(saved_model_path)
        if model_type == "tensorflow":
            import tensorflow as tf

            loaded_model = tf.keras.models.load_model(saved_model_path)

            # Start an MLflow run
            with mlflow.start_run():
                # Log the TensorFlow model to MLflow
                mlflow.tensorflow.log_model(
                    model=loaded_model,
                    artifact_path=f"{model_type}-{name}",
                    registered_model_name=name,
                )
        if model_type == "sklearn":
            # Load the model from the saved file
            model = joblib.load(saved_model_path)

            # Start an MLflow run
            with mlflow.start_run():
                mlflow.sklearn.log_model(
                    model,
                    artifact_path=f"{model_type}-{name}",
                    registered_model_name=name,
                )
        if model_type == "pytorch":
            absolute_path_to_class = abs_path(class_path)
            class_name = class_instance  # "model"
            model_path = saved_model_path

            class_directory = path.dirname(absolute_path_to_class)
            sys.path.append(class_directory)

            # Get module name
            module_name = os.path.basename(absolute_path_to_class)

            # Load the module dynamically
            spec = importlib.util.spec_from_file_location(
                module_name, absolute_path_to_class
            )
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            # Get the class instance from the module
            loaded_model = getattr(module, class_name)

            import torch

            # Load the saved model parameters
            loaded_model.load_state_dict(torch.load(model_path))
            loaded_model.eval()  # Set the model to evaluation mode

            # Start an MLflow run
            with mlflow.start_run():
                mlflow.pytorch.log_model(
                    loaded_model,
                    artifact_path=f"{model_type}-{name}",
                    registered_model_name=name,
                )
        if model_type == "xgboost":
            import xgboost as xgb

            loaded_model = xgb.Booster()
            loaded_model.load_model(saved_model_path)

            # Start an MLflow run
            with mlflow.start_run():
                mlflow.xgboost.log_model(
                    loaded_model,
                    artifact_path=f"{model_type}-{name}",
                    registered_model_name=name,
                )
        if model_type == "custom_model":
            with mlflow.start_run():
                mlflow.log_artifacts(saved_model_path, artifact_path=f"{name}")
                tmodel = TrainedModel("cust_model")
                mlflow.pyfunc.log_model(
                    f"{name}",
                    python_model=tmodel,
                    artifacts={
                        f"{name}": mlflow.get_artifact_uri(artifact_path=f"{name}")
                    },
                    registered_model_name=f"{name}",
                )
        if output is None:
            click.echo(f"Model {name} imported successfully.")
        else:
            click.echo(output_convertion(f"Model {name} imported successfully.", output))
    except Exception as e:
            click.echo(f"Failed to import the model: {name} \n\nError: {e}")
@models.command()
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
def list(output):
    """List models registered in mlflow registry"""
    filter_string = None
    results = mlfc.search_registered_models(filter_string=filter_string)
    models = [["name", "latest_version", "runid", "status"]]

    for res in results:
        for mv in res.latest_versions:
            models.append([mv.name, mv.version, mv.run_id, mv.status])

    if output is None:
        print(tabulate(models, headers="firstrow", tablefmt="presto"))
    else:
        output_convertion(models, output)

'''
@models.command()
@click.argument("name")
def show(name):
    """Get details of a specific model"""
    mname = "name='{}'".format(name)
    details = []
    results = mlfc.search_model_versions(filter_string=mname)
    for result in results:
        proto = result.to_proto()
        key_list = proto.DESCRIPTOR.fields_by_name.keys()
        d = {}
        for key in key_list:
            d[key] = getattr(proto, key)
        details.append(d)
    if len(details) == 0:
        print(f"Model with name [{name}] not found.")
    else:
        header = details[0].keys()
        rows = [x.values() for x in details]
        print(tabulate(rows, header, tablefmt="presto"))


@models.command()
@click.argument("name")
def delete(name):
    """Delete registered model"""
    try:
        mlfc.delete_registered_model(name=name)
        click.echo(f"registered model: {name} is deleted")
    except Exception as e:
        click.echo(f"Failed to delete registered model: {name}")


@models.command()
@click.argument("name")
@click.argument("version")
@click.option("-a", "--archive", is_flag=True, help="archive")
@click.option("-d", "--delete", is_flag=True, help="delete")
def version(name, version, delete, archive):
    """Archive/Delete specific version of the model"""
    if not delete and not archive:
        click.echo("please provide either archive or delete option")
    if archive:
        try:
            mlfc.transition_model_version_stage(
                name=name, version=version, stage="Archived"
            )
            click.echo(f"model: {name}, version: {version} is archived")
        except Exception as e:
            click.echo(f"Failed to archive model: {name}, version: {version}")

    if delete:
        try:
            mlfc.delete_model_version(name=name, version=version)
            click.echo(f"model: {name}, version: {version} is deleted")
        except Exception as e:
            click.echo(f"Failed to delete model: {name}, version: {version}")
'''
