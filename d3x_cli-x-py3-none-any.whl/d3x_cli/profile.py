import click
import requests
import json
import os
from tabulate import tabulate
from pathlib import Path
from d3x_cli.utils import  get_request_headers,output_convertion
from d3x_cli.login import get_auth_cookie
from urllib3 import Timeout, PoolManager
import subprocess
import yaml
requests.packages.urllib3.disable_warnings()
timeout = Timeout(connect=1, read=2)
http = PoolManager(timeout=timeout, cert_reqs='CERT_NONE')

userdata_dir = "/userdata" if "D3X_NAMESPACE" in os.environ else str(Path.home())
ini_file = f"{userdata_dir}/.d3x.ini"

@click.group()
@click.pass_obj
def profile(obj):
    """Group for profile commands."""
    pass

def d3x_login(config, profile_name):
    url = config.get(profile_name,"url")
    print(f"login to {url} using {profile_name} profile")
    authtype = config.get(profile_name,"auth-type",fallback="cookie")
    if "D3X_NAMESPACE" in os.environ:
        authtype = "apikey"
        apiprefix = "d3x"
    else :
        authtype = click.prompt("Auth Type (cookie/apikey)", default=authtype)

    if authtype == "cookie":
        cookie = get_auth_cookie(url)
        if cookie:
            print("logged in.")
        apiprefix = "ds"
        config.set(profile_name, "cookie", cookie)
        headers = get_request_headers(cookie=cookie)
    elif authtype == "apikey" :
        apiprefix = "d3x"
        token = click.prompt("ApiKey", default="")
        config.set(profile_name, "auth-token", token)
        headers = get_request_headers(token=token)
    else:
        print("invalid auth type")
        raise click.Abort()
    config.set(profile_name, "auth-type", authtype)
    config.set(profile_name, "api-prefix", apiprefix)
    
    r = http.request('GET', url + f"/api/{apiprefix}/me", headers=headers, retries=False)
    if r.status == 200:
        resp = json.loads(r.data)
        config.set(profile_name, "username", resp["name"])
    elif r.status == 302 or  r.status == 401:
        print("Invalid credential please retry with valid credential")
        raise click.Abort()
    else:
        print(f"operation failed with {r.status} please retry")
    with open(ini_file, "w") as f:
        config.write(f)

def configure_local_profile(config):
    profile_name = "dkubex"
    namespace = os.environ["D3X_NAMESPACE"]
    url = f"http://ingress-nginx-controller.{namespace}.svc.cluster.local:80"
    if profile_name not in config.sections():
        config.add_section(profile_name)

    url = config.get(profile_name,"url",fallback=url)
    click.echo("Please configure external url for getting URL links accessible outside dkubex")
    url = click.prompt("D3X URL", default=url)
    if url[-1] == "/":
        url = url[:-1]
    config.set(profile_name, "url", url)
    config.set(profile_name, "workspace", "default workspace")
    config.set(profile_name, "cluster-type", "local")
    token = ""
    with open(f'{userdata_dir}/.apikey', 'r') as file:
        token = file.read().rstrip()
    config.set(profile_name, "auth-token", token)
    config.set(profile_name, "auth-type", "apikey")
    config.set(profile_name, "api-prefix", "d3x")
    if "default" not in config.sections() and not config.has_option("default","profile"):
        config.add_section("default")
        config.set("default", "profile", profile_name)
    headers = get_request_headers(token=token)
    r = http.request('GET', url + f"/api/d3x/me", headers=headers, retries=False)
    if r.status == 200:
        resp = json.loads(r.data)
        config.set(profile_name, "username", resp["name"])
    with open(ini_file, "w") as f:
        config.write(f)

def configure_profile(config, profile_name = None):
    while profile_name == None:
        profile_name = click.prompt("Enter profile name")
        if profile_name == "default":
            click.echo(f"profile name '{profile_name}' is not supported, please use another name")
            profile_name = None
    if "D3X_NAMESPACE" in os.environ: 
        if profile_name == "dkubex":
            return configure_local_profile(config)

    if profile_name not in config.sections():
        config.add_section(profile_name)
    config.set(profile_name, "cluster-type", "remote")

    url = config.get(profile_name,"url",fallback="")
    url = click.prompt("D3X URL", default=url)
    if url[-1] == "/":
        url = url[:-1]

    config.set(profile_name, "url", url)
    config.set(profile_name, "workspace", "default workspace")
    default_profile  = click.prompt("Do you wanted to make this profile as default", default="yes")
    if default_profile == "yes":
        if "default" not in config.sections():
            config.add_section("default")
        config.set("default", "profile", profile_name)
    d3x_login(config, profile_name)
    return profile_name

@profile.command()
@click.pass_obj
def configure(obj):
    """Configure profile"""
    configure_profile(obj)

@profile.command()
@click.pass_obj
@click.argument("profile")
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
def set(obj, profile,output):
    """Set default profile"""
    config = obj
    if profile not in config:
        click.echo(f"profile {profile} not found")
        return
    if "default" not in config.sections():
        config.add_section("default")
    config.set("default", "profile", profile)

    with open(ini_file, "w") as f:
        config.write(f)
    if output is None:
        print(f"updated default profile to {profile}")
    else:
        profile_output=f"updated default profile to {profile}"
        output_convertion(profile_output, output)
        
    # print(f"updated default profile to {profile}")

@profile.command()
@click.pass_obj
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
def list(obj,output):
    """list profiles"""
    config = obj
    default_profile = None
    if "default" in config.sections() and config.has_option("default","profile"):
            default_profile = config.get("default","profile")
    profiles = [[ "name", "url", "username", "auth type"]]
    for p  in config.sections():
        if p == "default":
            continue
        name = p
        if default_profile == name:
            name = f"{name}*"
        url = config.get(p,"url")
        username = config.get(p,"username")
        auth = config.get(p,"auth-type")
        profiles.append([name, url, username, auth])
    if output is None:
        print(tabulate(profiles, headers="firstrow", tablefmt="presto"))
    else:
        output_convertion(profiles, output)
@profile.command()
@click.pass_obj
@click.argument("profile")
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)


def delete(obj, profile,output):
    """delete profile"""
    if "D3X_NAMESPACE" in os.environ: 
        if profile == "dkubex":
            click.echo(f"can not delete system profile {profile}")
            raise click.Abort() 
    config = obj
    if profile not in config:
        click.echo(f"profile {profile} not found")
        raise click.Abort()
    if "default" in config.sections() and config.has_option("default","profile"):
            default_profile = config.get("default","profile")
            if default_profile == profile:
                config.remove_section("default")
    config.remove_section(profile)
    with open(ini_file, "w") as f:
        config.write(f)
    if output is None:
        print(f"deleted profile {profile}")
    else:
        delete_profile=f"deleted profile {profile}"
        output_convertion(delete_profile, output)
    # print(f"deleted profile {profile}")
