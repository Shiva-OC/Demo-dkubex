import click
import requests
from tabulate import tabulate


@click.group()
@click.pass_obj
def mlflow(obj):
    """Group for mlflow commands."""
    global CLI_CTX_OBJ
    CLI_CTX_OBJ = obj


@click.group()
@click.pass_obj
def experiments(obj):
    """mlflow experiments."""
    pass


@click.group()
@click.pass_obj
def models(obj):
    """mlflow models."""
    pass


@experiments.command()
@click.pass_obj
@click.argument("id")
def delete(obj, id):
    """Delete Experiment"""
    click.echo(f"please wait while deleting the experiment: {id}")
    resp = requests.delete(
        f"{obj.url}/api/{obj.api_prefix}/mlflow/experiments/{id}/delete",
        headers=obj.headers,
        verify=False,
    )
    if resp.status_code != 200:
        click.echo(resp.text)
        raise click.Abort()
    click.echo(resp.json())


@experiments.command()
@click.pass_obj
@click.argument("id")
def archive(obj, id):
    """Archive Experiment"""
    click.echo(f"please wait while archiving the experiment: {id}")
    resp = requests.post(
        f"{obj.url}/api/{obj.api_prefix}/mlflow/experiments/{id}/archive",
        headers=obj.headers,
        verify=False,
    )
    if resp.status_code != 200:
        click.echo(resp.text)
        raise click.Abort()
    click.echo(resp.json())


@experiments.command()
@click.pass_obj
def list(obj):
    """List Experiments"""
    resp = requests.get(
        f"{obj.url}/api/{obj.api_prefix}/mlflow/experiments",
        headers=obj.headers,
        verify=False,
    )
    if resp.status_code != 200:
        click.echo(resp.text)
        raise click.Abort()
    results = resp.json()
    exps = [["experiments_id", "name", "artifact_location", "life_cycle_stage", "tags"]]

    for val in results:
        exps.append(
            [
                val["_experiment_id"],
                val["_name"],
                val["_artifact_location"],
                val["_lifecycle_stage"],
                val["_tags"],
            ]
        )
    print(tabulate(exps, headers="firstrow", tablefmt="presto"))


@experiments.command()
@click.pass_obj
@click.argument("id")
def restore(obj, id):
    """Restore Experiment"""
    click.echo(f"please wait while restoring the experiment: {id}")
    resp = requests.post(
        f"{obj.url}/api/{obj.api_prefix}/mlflow/experiments/{id}/restore",
        headers=obj.headers,
        verify=False,
    )
    if resp.status_code != 200:
        click.echo(resp.text)
        raise click.Abort()
    click.echo(resp.json())


@models.command()
@click.pass_obj
@click.argument("name")
@click.argument("version")
def delete(obj, name, version):
    """Delete Model"""
    click.echo(f"please wait while deleting the model: {name}, version: {version}")
    resp = requests.delete(
        f"{obj.url}/api/{obj.api_prefix}/mlflow/models/{name}/{version}",
        headers=obj.headers,
        verify=False,
    )
    if resp.status_code != 200:
        click.echo(resp.text)
        raise click.Abort()
    click.echo(resp.json())


@models.command()
@click.pass_obj
@click.argument("name")
@click.argument("version")
def archive(obj, name, version):
    """Archive Model"""
    click.echo(f"please wait while archiving the model: {name}, version: {version}")
    resp = requests.post(
        f"{obj.url}/api/{obj.api_prefix}/mlflow/models/{name}/{version}",
        headers=obj.headers,
        verify=False,
    )
    if resp.status_code != 200:
        click.echo(resp.text)
        raise click.Abort()
    click.echo(resp.json())


mlflow.add_command(experiments)
mlflow.add_command(models)
