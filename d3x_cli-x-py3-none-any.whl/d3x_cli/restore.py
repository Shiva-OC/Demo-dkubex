import click
import sys
from websockets.sync.client import connect
import websockets
import json
import os
import requests
import asyncio
import signal
import ssl
from websockets.exceptions import ConnectionClosedError

ssl_context = ssl.SSLContext()
ssl_context.verify_mode = ssl.CERT_NONE

class ContextObj(object):
    def __init__(self):
        self.url = "http://localhost:8000"
        self.auth_type = "cookie"
        self.headers = {"authorization": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoicnNpbmdoIn0.E5Ae9aZK6WAC36r4X2BD6QJhk_1jvC829anGaZ14vjU0"} 

@click.group()
@click.pass_context
def main(ctx):
    ctx.obj = ContextObj()

def _restore(obj, script, args, api_key, name):
    data = {"pwd": os.getcwd(), "script":script, "args": args, "api_key": api_key, "name": name}
    if "--help" in args:
        r = requests.post(obj.url + "/help", json=data, headers=obj.headers, verify=False, allow_redirects=False)
    else:
        r = requests.post(obj.url + "/run", json=data, headers=obj.headers, verify=False, allow_redirects=False)
    if r.status_code == 200:
        print(r.json())
        return r.json()
    return None

def _logs(obj, job_name):
    url = obj.url.replace("http","ws")
    with connect(f"{url}/logs/{job_name}", additional_headers=obj.headers, open_timeout=420) as websocket:
        try:
            for msg in websocket:
                print(msg, end="", flush=True)
        except ConnectionClosedError:
            print("Timed out waiting. "
              "Please tail the logs using the following command: \n"
              f"kubectl logs -l job-name={job_name} --follow")
        except:
            websocket.close()
            raise

def connect_websocket(url, ssl_context, additional_headers, open_timeout):
    if url.startswith('wss'):
        return connect(url, ssl_context=ssl_context, additional_headers=additional_headers, open_timeout=open_timeout)
    else:
        return connect(url, additional_headers=additional_headers, open_timeout=open_timeout)

@click.group()
@click.pass_obj
def restore(obj):
    """Group for restore commands."""
    if obj.auth_type == "cookie":
        obj.url += "/api/fm"
    else:
        obj.url += "/api/fm-api"

@restore.command(context_settings=dict(ignore_unknown_options=True, help_option_names=[]))
@click.pass_obj
@click.argument('docs_args', nargs=-1, type=click.UNPROCESSED)
@click.option("-k","--api_key", default="", envvar="OPENAI_API_KEY")
@click.option("-n","--name", help="job name")
def weaviate(obj, api_key, docs_args, name):
    """command for weaviate restore"""
    resp = _restore(obj, "dkubex-fm/weaviate-restore.py", docs_args, api_key, name)

    if resp and type(resp) == dict and resp["status"] == "OK":
        _logs(obj, resp["job"])


main.add_command(restore)
if __name__ == "__main__":
    sys.exit(main())  # pragma: no cover