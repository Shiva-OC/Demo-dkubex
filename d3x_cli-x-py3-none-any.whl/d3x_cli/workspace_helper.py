import requests
from tabulate import tabulate
import click
from d3x_cli.utils import  get_formatted_name, output_convertion, catch_os_exec
import os
import platform
import subprocess
host_type = platform.system()

class Struct:
    def __init__(self, **entries):
        self.__dict__.update(entries)

def get_workspaces(obj, ns=None):
    url = obj.url
    params = {}
    if ns != None:
        params={"namespace": ns}
    r = requests.get(url + f"/api/{obj.api_prefix}/workspaces/", params=params, headers=obj.headers, verify=False)
    if r.status_code == 200:
        return r.json()
    else:
        print(r.text)
    return []

def get_user_workspace(obj, user= None, exit = True):
    if user == None:
        user = obj.username
    data = get_workspaces(obj, user)
    workspace = None
    for d in data:
        if d["owner"] == user:
            workspace = d
            break
    if workspace == None:
        if exit:
            print(f"workspace for the user {user} not found")
            raise click.Abort()
        else:
            return None
    return Struct(**workspace)

def get_template_id(url, cookie, type, name):
    r = requests.get(url + f"/api/ds/template/{type}/", cookies={"_oauth2_proxy": cookie}, verify=False)
    if r.status_code != 200:
        print(f"Failed to get {type} template {name}:" + r.text)
        raise click.Abort()
    templates = r.json()
    
    template_id = -1
    for template in templates:
        if template["name"] == name:
            assert template_id == -1, f"Multiple {type} templates with {name}"
            template_id = template["id"]
    
    assert template_id != -1, f"No {type} templates found with {name}"
    return template_id

def list_workspaces(obj, output, all=None):
    data = get_workspaces(obj, all)
    workspaces = [["id", "user", "status", "image", "memory(GB)", "cores", "gpu", "created", "apps"]]
    for workspace in data:
        w = Struct(**workspace)
        apps = ",".join(a["name"] for a in w.apps)
        workspaces.append([w.id, w.owner, w.status, w.image, w.memory, w.cpu_count, w.gpu_count, w.created_at, apps])
    if output is None:
        print(tabulate(workspaces, headers="firstrow", tablefmt="presto"))
    else:
        output_convertion(workspaces, output)

def start_stop_workspace(obj, op, ns=None):
    url = obj.url
    w = get_user_workspace(obj, ns)
    if op == "stop":
        print(f"stopping {w.name} ...", end="")
    elif op == "start":
        print(f"starting {w.name} ...", end="")
    else :
        print(f"resetting {w.name} ...", end="")

    r = requests.post(url + f"/api/{obj.api_prefix}/workspaces/{w.id}/{op}", headers=obj.headers, verify=False)
    if r.status_code == 200:
        print("done")
    else:
        print(r.text)

def start_stop_workspace_app(obj, app_name, op, ns=None):
    url = obj.url
    w = get_user_workspace(obj, ns)
    if op == "stop":
        print(f"stopping {app_name} in {w.name}...", end="")
    elif op == "start":
        print(f"starting {app_name} in {w.name}...", end="")

    r = requests.post(url + f"/api/{obj.api_prefix}/workspaces/{w.id}/{op}/{app_name}", headers=obj.headers, verify=False)
    if r.status_code == 200:
        print("done")
    else:
        print(r.text)