import click
import requests
import json
from d3x_cli.utils import  get_formatted_name,output_convertion
from d3x_cli.workspace_helper import *
from websockets.sync.client import connect
from websockets.exceptions import ConnectionClosedError
import ssl
import asyncio
import os
import mlflow

def check_mlflow_run_exists(user, name):
    filter_string = f"tags.user='{user}' and tags.finetuning_name='{name}'"
    runs = mlflow.search_runs(filter_string=filter_string, search_all_experiments=True)
    if len(runs) > 0 :
        return True
    return False

@click.group()
@click.pass_obj
def ft(obj):
    """Group for finetuning commands."""
    global CLI_CTX_OBJ
    CLI_CTX_OBJ = obj

def _logs(obj, job_name):
    url = obj.url.replace("http","ws")
    with connect(f"{url}/logs/{job_name}", additional_headers=obj.headers, open_timeout=420, ssl_context=ssl._create_unverified_context()if "wss" in url else None) as websocket:
        try:
            for msg in websocket:
                msg = msg.replace("\\n", "\n").replace("\"","")
                print(msg, end="", flush=True)
        except ConnectionClosedError:
            print("Timed out waiting. "
              "Please tail the logs using the following command: \n"
              f"kubectl logs -l job-name={job_name} --follow")
        except:
            websocket.close()
            raise


def _fthandler(obj, args, api_key, name, op, **kwargs):
    data = {"pwd": os.getcwd(), "args": args, "api_key": api_key, "name": name, "op":op, **kwargs}
    if "--help" in args or args[0] in ["delete", "show", "list"]:
        r = requests.get(obj.url + "/help", json=data, headers=obj.headers, verify=False, allow_redirects=False)
    else:
        r = requests.post(obj.url + "/run", json=data, headers=obj.headers, verify=False, allow_redirects=False)
    if r.status_code == 200:
        return r.json()
    else:
        rsp = r.json()
        if 'detail' in rsp:
            print(rsp['detail'])
        else:
            print(rsp)
        raise click.Abort()


@ft.command(context_settings=dict(ignore_unknown_options=True, help_option_names=[]))
@click.pass_obj
@click.pass_context
@click.argument('ft_args', nargs=-1, type=click.UNPROCESSED)
@click.option("-n","--name", help="A name to represent the finetune job")
@click.option("-c","--config", help="User configuration for pipeline stages")
@click.option('-u','--dkubex-url', "dkubex_url", type=click.STRING, required=False, default="", help="URL of the dkubex for the remote clusters to reach.")
@click.option("--mlflow_experiment","mlflow_experiment", help="mlflow experiment name for tracking",required=False)
def finetune(ctx, obj, name, config, dkubex_url, mlflow_experiment = None, ft_args=None):
    """finetuning of model"""
    r = requests.get(f"{obj.url}/api/{obj.api_prefix}/apikey/", headers=obj.headers, verify=False)
    if r.status_code != 200:
        click.echo(r.text)
        raise click.Abort()
    api_key=r.json()
    if name == None or config == None :
        ft_args = ('finetune',  '--help')
    elif "--help" not in ft_args:
        command = ('finetune',)
        ft_args = command + ft_args 
        try:
            import yaml
            with open(config, "r") as fp:
                conf_yaml = yaml.safe_load(fp)
                ft_args = ft_args + ('-c', json.dumps(conf_yaml))
        except Exception as e:
            ft_args = ft_args + ('-c', config)
    if mlflow_experiment == None:
        mlflow_experiment = name
    if obj.auth_type == "cookie":
        obj.url += "/api/ft"
    else:
        obj.url += "/api/ft-api"
    resp = _fthandler(obj, ft_args, api_key, name, "finetune", dkubex_url=dkubex_url, mlflow_experiment=mlflow_experiment)
    if  "--help" in ft_args:
        print(ctx.get_help())
        lines = resp.splitlines()
        substring = '--kind'
        index = next((i for i, line in enumerate(lines) if substring in line), None)
        del lines[:index]
        print("\n".join(l for l in lines))
    else:
        print(resp)
    
    if "--dryrun" in ft_args:
        return
    if resp and type(resp) == dict and resp["status"] == "OK":
        _logs(obj, resp["job"])
        _details(obj, resp["job"])

@ft.command()
@click.pass_obj
def jobs(obj):
    """list finetuning jobs"""
    prefix = "api/ft" if obj.auth_type == "cookie" else "api/ft-api"  
    r = requests.get(f"{obj.url}/{prefix}/jobs",  headers=obj.headers, verify=False)
    print(r.text.replace("\\n", "\n").replace("\"",""))

def _details(obj, name):
    r = requests.get(f"{obj.url}/jobs/{name}",  headers=obj.headers, verify=False)
    if r.status_code == 200:
        print(json.dumps(r.json(),  indent=2))
    else :
        print(r.text)

@ft.command()
@click.pass_obj
@click.argument( "name", required=True)
def details(obj,name):
    """finetuning job details"""
    if obj.auth_type == "cookie":
        obj.url += "/api/ft"
    else:
        obj.url += "/api/ft-api"
    _details(obj, name)

@ft.command()
@click.pass_obj
@click.argument( "name", required=True)
def logs(obj,name):
    """finetuning job logs"""
    obj.url +="/api/ft" if obj.auth_type == "cookie" else "/api/ft-api" 
    _logs(obj, name)


@ft.command()
@click.pass_obj
@click.argument( "name", required=True)
def delete(obj,name):
    """delete finetuning jobs"""
    prefix = "api/ft" if obj.auth_type == "cookie" else "api/ft-api"  
    r = requests.delete(f"{obj.url}/{prefix}/jobs/{name}",  headers=obj.headers, verify=False)
    if r.status_code == 200:
        print(r.text.replace("\\n", "\n").replace("\\\"",""))
    else :
        print(r.text())


@ft.command()
@click.pass_obj
@click.option('-k', '--kind', "kind", required=True,  help="finetuning type llm/flagemb/stemb/layoutllm")
def list_configs(obj, kind):
    """list predefined finetuning configs"""
    if obj.auth_type == "cookie":
        obj.url += "/api/ft"
    else:
        obj.url += "/api/ft-api"
    data = {"args":  ['list-configs', '-k', kind], }
    r = requests.get(obj.url + "/run", json=data, headers=obj.headers, verify=False, allow_redirects=False)
    if r.status_code == 200:
        print(r.json())
    else:
        print(r.text())
    
@ft.command()
@click.pass_obj
@click.option("-n", "--name", "name", required=True, help="name of the config")
@click.option('-k', '--kind', "kind", required=True,  help="finetuning type llm/flagemb/stemb/layoutllm")
def get_config(obj, name, kind):
    """get predefined finetuning config"""
    
    if obj.auth_type == "cookie":
        obj.url += "/api/ft"
    else:
        obj.url += "/api/ft-api"
    data = {"args":  ['get-config', "-k", kind, "-n", name], }
    r = requests.get(obj.url + "/run", json=data, headers=obj.headers, verify=False, allow_redirects=False)
    if r.status_code == 200:
        print(r.json())
    else:
        print(r.text())

@ft.command(context_settings=dict(ignore_unknown_options=True, help_option_names=[]))
@click.pass_obj
@click.argument('ft_args', nargs=-1, type=click.UNPROCESSED)
@click.option("-n","--name", help="job name")
def merge(obj, name, ft_args=None):
    """create finetuning job"""
    r = requests.get(f"{obj.url}/api/{obj.api_prefix}/apikey/", headers=obj.headers, verify=False)
    if r.status_code != 200:
        click.echo(r.text)
        raise click.Abort()
    api_key=r.json()
    if name == None :
        ft_args = ('tune', 'merge', '--help')
    elif "--help" not in ft_args:
        command = ('tune', 'merge')
        ft_args = command + ft_args 
      
    if obj.auth_type == "cookie":
        obj.url += "/api/ft"
    else:
        obj.url += "/api/ft-api"
    resp = _fthandler(obj, ft_args, api_key, name, "merge")
    print(resp)
    if "--dryrun" in ft_args:
        return
    if resp and type(resp) == dict and resp["status"] == "OK":
        _logs(obj, resp["job"])
        _details(obj, resp["job"])

@ft.command(context_settings=dict(ignore_unknown_options=True, help_option_names=[]))
@click.pass_obj
@click.argument('ft_args', nargs=-1, type=click.UNPROCESSED)
@click.option("-n","--name", help="job name")
def quantize(obj, name,ft_args=None):
    """create finetuning job"""
    r = requests.get(f"{obj.url}/api/{obj.api_prefix}/apikey/", headers=obj.headers, verify=False)
    if r.status_code != 200:
        click.echo(r.text)
        raise click.Abort()
    api_key=r.json()
    if name == None :
        ft_args = ('tune', 'quantize', '--help')
    elif "--help" not in ft_args:
        command = ('tune', 'quantize')
        ft_args = command + ft_args 
        
    if obj.auth_type == "cookie":
        obj.url += "/api/ft"
    else:
        obj.url += "/api/ft-api"
    resp = _fthandler(obj, ft_args, api_key, name, "quantize")
    print(resp)
    if "--dryrun" in ft_args:
        return
    if resp and type(resp) == dict and resp["status"] == "OK":
        _logs(obj, resp["job"])
        _details(obj, name)