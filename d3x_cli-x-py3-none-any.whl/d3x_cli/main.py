import click
from configparser import ConfigParser
from pathlib import Path
import requests
import json
from urllib3 import Timeout, PoolManager
import os, sys
import subprocess
from datetime import datetime
import re
import platform
from d3x_cli.utils import catch_os_exec, get_request_headers, ContextObj
from d3x_cli.workspace import ws
from d3x_cli.serve import serve
from d3x_cli.llms import llms
from d3x_cli.emb import emb
from d3x_cli.token import apikey
from d3x_cli.fm import fm
from d3x_cli.backup import backup
from d3x_cli.restore import restore
from d3x_cli.mlflowcli import mlflow
from d3x_cli.metrics import get_workspace_usage, get_nodes_usage
import pkg_resources
from rich.live import Live
from sseclient import SSEClient
from rich.layout import Layout
import getpass
from d3x_cli.userapps import apps
from tabulate import tabulate
from d3x_cli.profile import profile, d3x_login, configure_profile, configure_local_profile,output_convertion
import websockets
from websockets.sync.client import connect
from websockets.exceptions import ConnectionClosedError
import ssl
import asyncio
from d3x_cli.ft import ft

requests.packages.urllib3.disable_warnings()
timeout = Timeout(connect=1, read=2)
http = PoolManager(timeout=timeout, cert_reqs='CERT_NONE')
config = ConfigParser()
userdata_dir = "/userdata" if "D3X_NAMESPACE" in os.environ else str(Path.home())
ini_file = f"{userdata_dir}/.d3x.ini"

config.read(ini_file)
if "D3X_NAMESPACE" in os.environ:
    os.environ["PYTHONUSERBASE"] = "intentionally-disabled"
    if "dkubex" not in config.sections():
        configure_local_profile(config)

install_cmd = "pip3 install --upgrade d3x-cli"
host_type = platform.system()

'''
if "D3X_NAMESPACE" in os.environ:
    shell = os.environ["SHELL"].split("/")[-1] if "SHELL" in os.environ else ""
    if shell in ["bash", "zsh"]:
        filename = userdata_dir + f"/.d3x-complete.{shell}rc"
        command = f'_DCLI_COMPLETE={shell}_source d3x'
        process = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        open(filename,"wb").write(process.stdout)
        print(f"Append source {filename} in ~/.{shell}rc for command auto-completion")
'''

def get_base_prefix_compat():
    """Get base/real prefix, or sys.prefix if there is none."""
    return (getattr(sys, "base_prefix", None) or getattr(sys, "real_prefix", None) or sys.prefix)


def in_virtualenv():
    return get_base_prefix_compat() != sys.prefix

def get_formatted_name(name) :
    name=re.sub('[^A-Za-z0-9-]+', '-', name).lower()
    return name.strip("-")

def _validate_login(profile_name):
    auth_type = config.get(profile_name,"auth-type")
    if auth_type == None:
        return d3x_login(config, profile_name)
    
    url = config.get(profile_name,"url")
    command = " ".join(sys.argv)
    version = pkg_resources.require("d3x-cli")[0].version
    json_data = json.dumps({"command": command, "version": version}) 
    while True:
        if auth_type == "cookie":
            cookie = config.get(profile_name,"cookie", fallback=None)
            api_prefix = "ds"
            headers = get_request_headers(cookie=cookie)
        else :
            token = config.get(profile_name,"auth-token", fallback=None)
            api_prefix = "d3x"
            headers = get_request_headers(token=token)
        r = http.request('POST', url + f"/api/{api_prefix}/cli", body = json_data, headers=headers, retries=False, timeout=120)
        if r.status == 302 or  r.status == 401:
            print("Invalid credential please enter credentials again")
            d3x_login(config, profile_name)
            continue
        elif r.status != 200:
            print(r.data)
            raise click.Abort()
        try:
            resp = json.loads(r.data)
            os.environ["NODE_IP"] = resp["ip"]
            os.environ["NAMESPACE"] = resp["namespace"]
        except Exception:
            print("Invalid credential please enter credentials again")
            d3x_login(config, profile_name)
        break

    r = http.request('GET', url + f"/api/{api_prefix}/me", headers=headers, retries=False, timeout=120)
    if r.status == 200:
        resp = json.loads(r.data)
        config.set(profile_name, "username", resp["name"])

@click.group()
@click.pass_context
@click.option("-d", "--debug", is_flag=True, help="enable requests debugging")
@click.option("--profile", required=False, help="cluster profile")
def main(ctx, debug, profile):
    """Group for d3x commands."""
    if debug:
        import http
        http.client.HTTPConnection.debuglevel = 1

    if "--help" in sys.argv and "sky" not in sys.argv and sys.argv[1] != "fm" and sys.argv[1] != "ft" and sys.argv[1] != "dataset" and sys.argv[1] != "backup" and sys.argv[1] != "restore":
        return
    
    if profile == None:
        profile = os.environ.get("D3X_PROFILE", None)
        if profile == "":
            profile = None

    if profile == None:
        if "default" in config.sections() and config.has_option("default","profile"):
            profile = config.get("default","profile")

    if ctx.invoked_subcommand != "profile":
        if profile not in config.sections():
            profile = configure_profile(config, profile if profile != "default" else None)

        if  config.get(profile,"cluster-type") == "local":
            with open('/userdata/.apikey', 'r') as file:
                token = file.read().rstrip()
                config.set(profile, "auth-token", token)

        if ctx.invoked_subcommand == "login":
            ctx.obj = profile
            return
        else:
            _validate_login(profile)
           
        workspace = "default workspace"
        if workspace:
            os.environ["D3X_WORKSPACE"] = workspace
        ctx.obj = ContextObj(config, profile)
    else:
        ctx.obj = config
main.add_command(ws)
main.add_command(mlflow)
main.add_command(llms)
main.add_command(emb)
main.add_command(serve)
main.add_command(apikey)
main.add_command(apps)
main.add_command(profile)
main.add_command(fm)
main.add_command(backup)
main.add_command(restore)
main.add_command(ft)

try:
    from d3x_cli.ray import ray
    main.add_command(ray)
except ImportError:
    pass

@main.command()
@click.pass_obj
def login(obj):
    """Login to D3X"""
    d3x_login(config, obj)
    _validate_login(obj)

@main.command()
@click.pass_obj
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
def about(obj,output):
    """Details about D3X CLI config"""
    url = config.get(obj.profile,"url")
    # print(f"url : {url}")
    username = config.get(obj.profile,"username")
    # print(f"username : {username}")
    auth = config.get(obj.profile,"auth-type")
    # print(f"auth type : {auth}")
    if output is None:
        print(f"url : {url}")
        print(f"username : {username}")
        print(f"auth type : {auth}")
    else:
        userurl=f"url : {url}"
        userusername=f"username : {username}"
        userauth=f"auth type : {auth}"
        userdetails=userurl,userusername,userauth
        output_convertion(userdetails, output)

@main.command()
@click.pass_obj
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json",
        ]
    ),
    help="supported only json,yaml",
)
def instance_types(obj,output):
    """List available instance types."""
    r = requests.get(f"{obj.url}/api/admin/instance-types", headers=obj.headers, verify=False)

    if r.status_code == 200:
        try:
            instance_types = r.json()
            if output is None:
                click.echo("Available instance types:")
                for instance_type in instance_types:
                    click.echo(instance_type)
            else:
                instance_types_dict = {"instance_types": instance_types}
                click.echo(output_convertion(instance_types_dict, output))
        except requests.exceptions.JSONDecodeError as e:
            click.echo("Error decoding JSON response")
    else:
        click.echo(f"Failed to fetch instance types: {r.status_code}")

@main.command()
@click.pass_obj
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
def version(obj,output):
    """Dkubex version"""
    r = requests.get(f"{obj.url}/api/{obj.api_prefix}/version/", headers=obj.headers, verify=False, allow_redirects=False)
    if r.status_code != 200:
        click.echo(r.text)
        raise click.Abort()
    if output is None:
        print("Dkubex version:", r.json())
    else:
        print("Dkubex version:", output_convertion(r.json(), output))

@main.command(context_settings=dict(ignore_unknown_options=True, help_option_names=[]))
@click.pass_obj
@click.argument('sky_args', nargs=-1, type=click.UNPROCESSED)
def sky(obj, sky_args):
    """Group for sky commands."""
    if (sky_args[0] == "down") and ("--help" not in sky_args):
        return asyncio.run(interactive_controller_delete(obj, sky_args))

    url = obj.url.replace("http","ws")
    with connect(f"{url}/sky/{sky_args[0]}", additional_headers=obj.headers, open_timeout=100, close_timeout=100, ssl_context=ssl._create_unverified_context() if "wss" in url else None) as websocket:
        data = {"pwd": os.getcwd(), "args": sky_args}
        websocket.send(json.dumps(data))
        try:
            for msg in websocket:
                print(msg, end="", flush=True)
        except ConnectionClosedError:
            print("Timed out waiting for job completion. \nUse the following command to tail the logs of job: \n d3x sky logs <cluster_name>.")

async def interactive_controller_delete(obj, sky_args):
    url = obj.url.replace("http", "ws")
    async with websockets.connect(f"{url}/sky/{sky_args[0]}", extra_headers=obj.headers, open_timeout=100, close_timeout=100, ssl=ssl._create_unverified_context() if "wss" in url else None) as websocket:
        data = {"pwd": os.getcwd(), "args": sky_args}
        await websocket.send(json.dumps(data))

        state = type('', (), {})()
        state.should_read = False

        async def msg_sender():
            while websocket.open:
                if state.should_read:
                    msg = input("") + "\n"
                    await websocket.send(msg)
                    state.should_read = False
                else:
                    await asyncio.sleep(1)

        async def msg_receiver():
            output = ""
            async for msg in websocket:
                print(msg, end="", flush=True)
                output += msg
                if "To proceed, please type 'delete': " in output:
                    output = ""
                    state.should_read = True

        try:
            await asyncio.gather(msg_sender(), msg_receiver())
        except:
            pass

@main.command()
@click.argument("bucket", required=False)
@click.argument("mountpath", required=False)
@click.option("-a","--all", help="mount all the previous buckets", is_flag=True)
def mount(bucket, mountpath, all):
    """mount s3 bucket in read write mode"""
    if "D3X_NAMESPACE" not in os.environ:
        raise click.UsageError("this command must be run inside dkubex workspace.")

    if os.path.exists("/usr/bin/mount-s3") is False:
        print("/usr/bin/mount-s3 binary does not exist.")
        raise click.Abort()

    if bucket and mountpath:
        subprocess.run(["mount-s3", bucket, mountpath, "--allow-delete"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if "s3" not in config.sections():
            config.add_section("s3")
        config.set("s3", bucket, mountpath)
        with open(ini_file, "w") as f:
            config.write(f)

    if all:
        for bucket, mountpath in config.items("s3"):
            print(f"mounting {bucket} to {mountpath}")
            subprocess.run(["mount-s3", bucket, mountpath, "--allow-delete"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)



@main.command()
@click.argument("mountpath")
def umount(mountpath):
    """unmount bucket previously mounted using mount command"""
    subprocess.run(["sudo", "umount", mountpath])
    for bucket, path in config.items("s3"):
        if path == mountpath:
            config.remove_option('s3', bucket)
            with open(ini_file, "w") as f:
                config.write(f)
            break


def _logs(obj, job_name):
    url = obj.url.replace("http","ws")
    with connect(f"{url}/logs/{job_name}", additional_headers=obj.headers, open_timeout=420, ssl_context=ssl._create_unverified_context()if "wss" in url else None) as websocket:
        try:
            for msg in websocket:
                print(msg, end="", flush=True)
        except ConnectionClosedError:
            print("Timed out waiting. "
              "Please tail the logs using the following command: \n"
              f"kubectl logs -l job-name={job_name} --follow")
        except:
            websocket.close()
            raise

def _handler(obj, script, args, api_key, name):
    data = {"pwd": os.getcwd(), "script":script, "args": args, "api_key": api_key, "name": name}
    if "--help" in args or args[0] in ["show", "list"]:
        r = requests.get(obj.url + "/help", json=data, headers=obj.headers, verify=False, allow_redirects=False)
    else:
        r = requests.post(obj.url + "/run", json=data, headers=obj.headers, verify=False, allow_redirects=False)
    if r.status_code == 200:
        print(r.json())
        return r.json()
    return None

@main.command(context_settings=dict(ignore_unknown_options=True, help_option_names=[]))
@click.pass_obj
@click.argument('docs_args', nargs=-1, type=click.UNPROCESSED)
@click.option("-n","--name", help="job name")
def dataset(obj, docs_args, name):
    """Group for dataset commands."""
    r = requests.get(f"{obj.url}/api/{obj.api_prefix}/apikey/", headers=obj.headers, verify=False)
    if r.status_code != 200:
        click.echo(r.text)
        raise click.Abort()
    api_key=r.json()

    if docs_args == None or len(docs_args) == 0:
        docs_args = ("--help")

    if "--help" not in docs_args and docs_args[0] in ["ingest", "evaluate"]:
        if ("-k" not in docs_args and  "--dkubex-apikey" not in docs_args):
           docs_args =  docs_args + ("-k", api_key)
        if ("--dkubex-url" not in docs_args):
            docs_args =  docs_args + ("--dkubex-url", obj.url)
      
    if obj.auth_type == "cookie":
        obj.url += "/api/fm"
    else:
        obj.url += "/api/fm-api"

    if ("-i" in docs_args or "--interactive" in docs_args) and "--help" not in docs_args :
        return asyncio.run(interactive_query(obj, api_key, docs_args, name))

    resp = _handler(obj, "dkubex-fm/cli.py", docs_args, api_key, name)

    if resp and type(resp) == dict and resp["status"] == "OK":
        _logs(obj, resp["job"])


async def interactive_query(obj, api_key, docs_args, name):
    data = {"pwd": os.getcwd(), "script":"dkubex-fm/cli.py", "args": docs_args, "api_key": api_key, "name": name}
    url = obj.url.replace("http","ws")
    async with websockets.connect(f"{url}/query",  extra_headers=obj.headers, open_timeout=420,  ssl=ssl._create_unverified_context() if "wss" in url else None) as websocket:
        await websocket.send(json.dumps(data))

        state = type('', (), {})()
        state.should_read = False

        async def msg_sender():
            while websocket.open:
                if state.should_read:
                    msg = input("") + "\n"
                    await websocket.send(msg.encode())
                    state.should_read = False
                else:
                    await asyncio.sleep(1)

        async def msg_receiver():
            output = ""
            async for msg in websocket:
                print(msg, end="", flush=True)
                output += msg
                if "Question>: " in output:
                    output = ""
                    state.should_read = True

        try:
            await asyncio.gather(msg_sender(), msg_receiver())
        except:
            pass
